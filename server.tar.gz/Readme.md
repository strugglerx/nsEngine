# 基于go的高校api接口

*静止用作非法用途,代码仅供参考*

|*说明*|*函数*
|:
|体育(测)信息|SportCurl(user string, pwd string) string{...}


```
结构:

## 数据汇总
type allData struct {
  Name         string      `json:"name"`
  ClassName    string      `json:"className"`
  ClassDetail  []ClassItem `json:"classDetail"`
  SportsDetail []SportItem `json:"sportsDetail"`
}

## 班级信息
type ClassItem struct {
  item string
  value string
}

## 体测信息
type SportItem struct {
  assess string
  name string
  score string
  single string
}

成功返回数据:"{...}"
失败返回数据:"-1"
```

|*说明*|*函数*
|:
|教务信息|EipEntry(User string, Type string, date string) string {...}

|*type:*|*说明*
|:
|class_|课表信息
|score|成绩信息
|info|学籍信息
|card|校园卡余额
|net|塞尔卡余额

```
部分结构说明:

##数据汇总
[]Custom

##学期信息
type Custom struct {
  Term   string       `json:"term"`
  Values []CustomItem `json:"values"`
}

##成绩信息
type CustomItem struct {
  Course     string      `json:"course"`
  Credit     interface{} `json:"credit"`
  Attributes string      `json:"attributes"`
  Score      string      `json:"score"`
}


正确返回数据:"{...}"
失败返回数据:"-1"
```
